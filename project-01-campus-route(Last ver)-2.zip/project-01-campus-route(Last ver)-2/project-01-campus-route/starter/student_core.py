from __future__ import annotations

import math
import heapq
from collections import deque
from typing import Callable, Dict, List, Optional, Tuple, Any

from graph import Graph, Node, Edge


def euclidean_heuristic(graph: Graph, node_a_id: str, node_b_id: str) -> float:
   """Calculate Euclidean distance (straight-line) between two nodes."""
   na = graph.get_node(node_a_id)
   nb = graph.get_node(node_b_id)
   return math.sqrt((na.x - nb.x) ** 2 + (na.y - nb.y) ** 2)


def manhattan_heuristic(graph: Graph, node_a_id: str, node_b_id: str) -> float:
   """Calculate Manhattan distance between two nodes."""
   na = graph.get_node(node_a_id)
   nb = graph.get_node(node_b_id)
   return abs(na.x - nb.x) + abs(na.y - nb.y)


def _reconstruct_path(parent_map: Dict[str, Optional[str]], start: str, goal: str) -> List[str]:
   """Helper function to reconstruct path from start to goal."""
   path = []
   curr: Optional[str] = goal
   while curr is not None:
       path.append(curr)
       curr = parent_map.get(curr)
   path.reverse()
   if path and path[0] == start:
       return path
   return []


def bfs(graph: Graph, start: str, goal: str, constraints: Optional[Dict[str, Any]] = None) -> Tuple[List[str], int]:
   """Breadth-First Search (BFS) algorithm."""
   if start == goal:
       return [start], 1

   queue = deque([start])
   visited = {start}
   parent = {start: None}
   nodes_expanded = 0

   blocked_edges = set(constraints.get("blocked_edges", [])) if constraints else set()
   accessible_only = constraints.get("accessible_only", False) if constraints else False

   while queue:
       curr = queue.popleft()
       nodes_expanded += 1

       if curr == goal:
           return _reconstruct_path(parent, start, goal), nodes_expanded

       for edge in graph.neighbors(curr):
           if accessible_only and not getattr(edge, 'accessible', True):
               continue
           edge_tuple = (edge.source, edge.target)
           rev_edge_tuple = (edge.target, edge.source)
           if edge_tuple in blocked_edges or rev_edge_tuple in blocked_edges:
               continue

           neighbor = edge.target if edge.source == curr else edge.source
           if neighbor not in visited:
               visited.add(neighbor)
               parent[neighbor] = curr
               queue.append(neighbor)

   return [], nodes_expanded


def dfs(graph: Graph, start: str, goal: str, constraints: Optional[Dict[str, Any]] = None) -> Tuple[List[str], int]:
    """Depth-First Search (DFS) algorithm using a stack."""
    if start == goal:
        return [start], 1

    stack = [start]
    visited = set()
    parent = {start: None}
    nodes_expanded = 0

    blocked_edges = set(constraints.get("blocked_edges", [])) if constraints else set()
    accessible_only = constraints.get("accessible_only", False) if constraints else False

    while stack:
        curr = stack.pop()

        if curr in visited:
            continue

        visited.add(curr)
        nodes_expanded += 1

        if curr == goal:
            return _reconstruct_path(parent, start, goal), nodes_expanded

        for edge in graph.neighbors(curr):
            if accessible_only and not getattr(edge, 'accessible', True):
                continue
            edge_tuple = (edge.source, edge.target)
            rev_edge_tuple = (edge.target, edge.source)
            if edge_tuple in blocked_edges or rev_edge_tuple in blocked_edges:
                continue

            neighbor = edge.target if edge.source == curr else edge.source
            if neighbor not in visited:
                if neighbor not in parent or parent[neighbor] is None:
                    parent[neighbor] = curr
                stack.append(neighbor)

    return [], nodes_expanded


def greedy(
   graph: Graph,
   start: str,
   goal: str,
   heuristic_fn: Callable[[Graph, str, str], float],
   constraints: Optional[Dict[str, Any]] = None,
) -> Tuple[List[str], int]:
   """Greedy Best-First Search algorithm."""
   counter = 0
   pq = [(heuristic_fn(graph, start, goal), counter, start)]
   visited = set()
   parent = {start: None}
   nodes_expanded = 0

   blocked_edges = set(constraints.get("blocked_edges", [])) if constraints else set()
   accessible_only = constraints.get("accessible_only", False) if constraints else False

   while pq:
       h_val, _, curr = heapq.heappop(pq)

       if curr in visited:
           continue

       visited.add(curr)
       nodes_expanded += 1

       if curr == goal:
           return _reconstruct_path(parent, start, goal), nodes_expanded

       for edge in graph.neighbors(curr):
           if accessible_only and not getattr(edge, 'accessible', True):
               continue
           edge_tuple = (edge.source, edge.target)
           rev_edge_tuple = (edge.target, edge.source)
           if edge_tuple in blocked_edges or rev_edge_tuple in blocked_edges:
               continue

           neighbor = edge.target if edge.source == curr else edge.source
           if neighbor not in visited:
               if neighbor not in parent:
                   parent[neighbor] = curr
               counter += 1
               h_next = heuristic_fn(graph, neighbor, goal)
               heapq.heappush(pq, (h_next, counter, neighbor))

   return [], nodes_expanded


def astar(
   graph: Graph,
   start: str,
   goal: str,
   heuristic_fn: Callable[[Graph, str, str], float],
   constraints: Optional[Dict[str, Any]] = None,
) -> Tuple[List[str], int]:
   """A* Search algorithm using standard constraints."""
   counter = 0
   g_score = {start: 0.0}
   f_start = heuristic_fn(graph, start, goal)
   pq = [(f_start, counter, start)]

   parent = {start: None}
   visited = set()
   nodes_expanded = 0

   blocked_edges = set(constraints.get("blocked_edges", [])) if constraints else set()
   accessible_only = constraints.get("accessible_only", False) if constraints else False
   optimize_weight = constraints.get("optimize_for", "distance") if constraints else "distance"

   while pq:
       f_val, _, curr = heapq.heappop(pq)

       if curr in visited:
           continue

       visited.add(curr)
       nodes_expanded += 1

       if curr == goal:
           return _reconstruct_path(parent, start, goal), nodes_expanded

       for edge in graph.neighbors(curr):
           if accessible_only and not getattr(edge, 'accessible', True):
               continue
           edge_tuple = (edge.source, edge.target)
           rev_edge_tuple = (edge.target, edge.source)
           if edge_tuple in blocked_edges or rev_edge_tuple in blocked_edges:
               continue

           neighbor = edge.target if edge.source == curr else edge.source
           cost = getattr(edge, 'travel_time', edge.distance) if optimize_weight == "travel_time" else edge.distance
           tentative_g = g_score[curr] + cost

           if neighbor not in g_score or tentative_g < g_score[neighbor]:
               g_score[neighbor] = tentative_g
               parent[neighbor] = curr
               f_score = tentative_g + heuristic_fn(graph, neighbor, goal)
               counter += 1
               heapq.heappush(pq, (f_score, counter, neighbor))

   return [], nodes_expanded


def get_multiple_routes(
       graph: Graph,
       start: str,
       goal: str,
       constraints: Optional[Dict[str, Any]] = None
) -> Dict[str, Dict[str, Any]]:
   """Generate all route options for all algorithms without filtering duplicates."""
   options = {}
   base_constraints = dict(constraints) if constraints else {}

   # Option 1: Optimal Route (A*)
   path_a, nodes_a = astar(graph, start, goal, euclidean_heuristic, base_constraints)
   if path_a:
       options["📍 1. Optimal (A*)"] = {
           "path": path_a, "nodes_expanded": nodes_a, "algo": "A* Search"
       }

   # Option 2: Fewest Intersections (BFS)
   path_bfs, nodes_bfs = bfs(graph, start, goal, base_constraints)
   if path_bfs:
       options["📍 2. Fewest Stops (BFS)"] = {
           "path": path_bfs, "nodes_expanded": nodes_bfs, "algo": "BFS"
       }

   # Option 3: Deepest Search (DFS)
   path_dfs, nodes_dfs = dfs(graph, start, goal, base_constraints)
   if path_dfs:
       options["📍 3. Deepest Search (DFS)"] = {
           "path": path_dfs, "nodes_expanded": nodes_dfs, "algo": "DFS"
       }

   # Option 4: Greedy Best-First Search
   path_greedy, nodes_greedy = greedy(graph, start, goal, euclidean_heuristic, base_constraints)
   if path_greedy:
       options["📍 4. Greedy Search"] = {
           "path": path_greedy, "nodes_expanded": nodes_greedy, "algo": "Greedy Best-First"
       }

   return options