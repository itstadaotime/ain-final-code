import json
from pathlib import Path
import streamlit as st
import pandas as pd
from datetime import datetime

from graph import load_graph
import student_core

PROJECT_DIR = Path(__file__).resolve().parent
DATA_DIR = PROJECT_DIR.parent / "data" if (PROJECT_DIR.parent / "data").exists() else PROJECT_DIR / "data"

st.set_page_config(
    page_title="Smart Campus Route Planner — Hanoi University (HANU)",
    page_icon="🏫",
    layout="wide"
)

@st.cache_data
def get_graph_data():
    return load_graph(DATA_DIR)

@st.cache_data
def get_scenarios():
    scenarios_path = DATA_DIR / "scenarios.json"
    if scenarios_path.exists():
        with open(scenarios_path, encoding="utf-8") as f:
            return json.load(f).get("scenarios", [])
    return []

try:
    graph = get_graph_data()
    scenarios = get_scenarios()
except Exception as e:
    st.error(f"Error loading data: {e}")
    st.stop()

st.title("🏫 Smart Campus Route Planner — Hanoi University (HANU)")

# ---------------- SIDEBAR ----------------
st.sidebar.header("📊 Graph Summary")
summary = graph.summary()
col_n, col_e = st.sidebar.columns(2)
col_n.metric("Nodes", summary["num_nodes"])
col_e.metric("Edges", summary["num_edges"])

all_nodes = [graph.get_node(nid) for nid in graph.node_ids]
buildings = sorted(list({node.building for node in all_nodes if getattr(node, 'building', None)}))
floors = sorted(list({node.floor for node in all_nodes if hasattr(node, 'floor')}))

st.sidebar.caption(f"**Buildings:** {', '.join(buildings)}")
st.sidebar.caption(f"**Floors:** {', '.join(map(str, floors))}")
st.sidebar.markdown("---")

st.sidebar.header("⚡ Scenario Presets")
scenario_dict = {"Custom Query": None}
for sc in scenarios:
    scenario_dict[f"{sc['id']} - {sc.get('name', '')}"] = sc

selected_sc_name = st.sidebar.selectbox("Quick Load Scenario", list(scenario_dict.keys()))
selected_sc = scenario_dict[selected_sc_name]

start_default = graph.node_ids[0]
goal_default = graph.node_ids[-1]
acc_default = False
block_main_road = False

if selected_sc:
    start_default = selected_sc.get("start", start_default)
    goal_default = selected_sc.get("end", goal_default)
    constraints_sc = selected_sc.get("constraints", {})
    acc_default = constraints_sc.get("accessible_only", False)
    if "blocked_edges" in constraints_sc and len(constraints_sc["blocked_edges"]) > 0:
        block_main_road = True

st.sidebar.markdown("---")
st.sidebar.header("⚙️ Search Controls")

node_options = {nid: f"{nid} — {graph.get_node(nid).name}" for nid in graph.node_ids}

start_node = st.sidebar.selectbox(
    "📍 Start node", graph.node_ids,
    index=graph.node_ids.index(start_default) if start_default in graph.node_ids else 0,
    format_func=lambda x: node_options[x]
)

goal_node = st.sidebar.selectbox(
    "🎯 End node", graph.node_ids,
    index=graph.node_ids.index(goal_default) if goal_default in graph.node_ids else len(graph.node_ids) - 1,
    format_func=lambda x: node_options[x]
)

algorithm = st.sidebar.selectbox(
    "Algorithm",
    ["Compare Multiple Routes (Options)", "A* Search", "Greedy Best-First", "BFS", "DFS"]
)
heuristic_type = st.sidebar.selectbox("Heuristic Function", ["Euclidean", "Manhattan"])
optimize_for = st.sidebar.selectbox("Optimize For (A* Weight)", ["distance", "travel_time"])

accessible_mode = st.sidebar.checkbox("♿ Accessibility Mode (Avoid Stairs)", value=acc_default)
block_road_cb = st.sidebar.checkbox("🚧 Block Main Road (W_CROSS_EAST ↔ W_SOUTH_STADIUM)", value=block_main_road)

constraints = {
    "accessible_only": accessible_mode,
    "blocked_edges": [("W_CROSS_EAST", "W_SOUTH_STADIUM")] if block_road_cb else [],
    "optimize_for": optimize_for
}

# ---------------- MAIN CONTENT ----------------
with st.expander("🗺️ Campus Wayfinding & Layout Map", expanded=True):
    map_image_path = DATA_DIR / "campus_map.png"
    if map_image_path.exists():
        st.image(str(map_image_path), width='stretch')
    else:
        st.info("Campus map image (campus_map.png) not found in data directory.")

st.subheader("🚀 Pathfinding Execution")
run_search = st.button("🔍 Find Route", type="primary")

def compute_route_stats(path_nodes):
    total_dist, total_time = 0.0, 0.0
    for i in range(len(path_nodes) - 1):
        u, v = path_nodes[i], path_nodes[i+1]
        for edge in graph.neighbors(u):
            neighbor = edge.target if edge.source == u else edge.source
            if neighbor == v:
                total_dist += getattr(edge, 'distance', 0.0)
                total_time += getattr(edge, 'travel_time', 0.0)
                break
    return total_dist, total_time


def render_route_details(path, expanded_nodes, algo_used):
    if not path:
        st.error("❌ No route found matching the selected constraints.")
        return

    total_dist, total_time = compute_route_stats(path)

    # --- ĐOẠN CODE THÊM MỚI: TỰ ĐỘNG GHI LOG VÀO FILE EXCEL/CSV ---
    log_file = DATA_DIR / "experiment_results.csv"
    new_record = pd.DataFrame([{
        "Thời gian test": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "Thuật toán": algo_used,
        "Điểm đi": path[0],
        "Điểm đến": path[-1],
        "Số bước": len(path) - 1,
        "Quãng đường (m)": round(total_dist, 1),
        "Thời gian dự kiến (s)": round(total_time, 1),
        "Số đỉnh đã duyệt": expanded_nodes
    }])

    # Ghi nối tiếp vào file bảng tính (dùng utf-8-sig để Excel không lỗi font tiếng Việt)
    if not log_file.exists():
        new_record.to_csv(log_file, mode='w', header=True, index=False, encoding='utf-8-sig')
    else:
        new_record.to_csv(log_file, mode='a', header=False, index=False, encoding='utf-8-sig')
    # --------------------------------------------------------------

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Total Steps", len(path) - 1)
    c2.metric("Distance", f"{total_dist:.1f} m")
    c3.metric("Est. Time", f"{total_time:.1f} s")
    c4.metric("Expanded Nodes", expanded_nodes)

    st.success(f"✅ Route Found via {algo_used}:")
    st.markdown(" **➔** ".join([f"`{nid}`" for nid in path]))

    st.subheader("🚶 Turn-by-Turn Route Guide")
    guide_data = []
    for idx, nid in enumerate(path):
        node = graph.get_node(nid)
        guide_data.append({
            "Step": idx + 1, "Node ID": nid, "Location Name": getattr(node, 'name', ''),
            "Building": getattr(node, 'building', 'Campus Grounds') or "Campus Grounds",
            "Floor": f"Floor {node.floor}" if getattr(node, 'floor', 0) > 0 else "Ground / Outdoor",
            "Type": str(getattr(node, 'node_type', '')).capitalize()
        })
    st.dataframe(pd.DataFrame(guide_data), width='stretch')

if run_search:
    h_fn = student_core.euclidean_heuristic if heuristic_type == "Euclidean" else student_core.manhattan_heuristic

    if algorithm == "Compare Multiple Routes (Options)":
        if not hasattr(student_core, 'get_multiple_routes'):
            st.error("Function 'get_multiple_routes' not found in student_core.py.")
        else:
            routes = student_core.get_multiple_routes(graph, start_node, goal_node, constraints)
            if not routes:
                st.error("❌ No route found satisfying the given constraints.")
            else:
                st.info(f"💡 System found {len(routes)} route options:")
                tabs = st.tabs(list(routes.keys()))
                for tab, (opt_name, opt_data) in zip(tabs, routes.items()):
                    with tab:
                        render_route_details(opt_data["path"], opt_data["nodes_expanded"], opt_data["algo"])
    else:
        if algorithm == "A* Search":
            path, exp_nodes = student_core.astar(graph, start_node, goal_node, h_fn, constraints)
        elif algorithm == "Greedy Best-First":
            path, exp_nodes = student_core.greedy(graph, start_node, goal_node, h_fn, constraints)
        elif algorithm == "DFS":
            path, exp_nodes = student_core.dfs(graph, start_node, goal_node, constraints)
        else:
            path, exp_nodes = student_core.bfs(graph, start_node, goal_node, constraints)

        render_route_details(path, exp_nodes, algorithm)